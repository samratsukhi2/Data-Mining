import matplotlib.pyplot as plt 

f=open('Data.csv','r')
s=[]
x=[]
y=[]
z=[]
w=[]
for i in f:
    if j<-1:
        break
    s=list(str(i).split(' '))
    x.append(s[1]) #time
    y.append(s[0]) #user
    z.append(s[2]) #method
    w.append(s[3]) #url
    

 